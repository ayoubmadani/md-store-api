import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  Request,
  UseGuards,
  HttpCode,
  HttpStatus,
  ParseUUIDPipe,
} from '@nestjs/common';
import { CategoryService } from './category.service';
import { CreateCategoryDto } from './dto/create-category.dto';
import { UpdateCategoryDto } from './dto/update-category.dto';
import { AuthGuard } from 'src/auth/guard/auth.guard';
import { QueryProductsDto } from './dto/query-products.dto';

@Controller('stores/:storeId/categories')
@UseGuards(AuthGuard)
export class CategoryController {
  constructor(private readonly categoryService: CategoryService) {}

  // ==================== إنشاء تصنيف جديد ====================
  
  @Post()
  @HttpCode(HttpStatus.CREATED)
  create(
    @Param('storeId', ParseUUIDPipe) storeId: string,
    @Body() dto: CreateCategoryDto,
    @Request() req,
  ) {
    return this.categoryService.create(storeId, req.user.userId, dto);
  }

  // ==================== جلب جميع التصنيفات كشجرة ====================
  
  @Get()
  findAll(
    @Param('storeId', ParseUUIDPipe) storeId: string, 
    @Request() req
  ) {
    return this.categoryService.findTrees(storeId, req.user.userId);
  }

  // ==================== البحث في التصنيفات ====================
  
  @Get('search')
  search(
    @Param('storeId', ParseUUIDPipe) storeId: string,
    @Query('q') searchTerm: string,
    @Request() req,
  ) {
    return this.categoryService.search(storeId, req.user.userId, searchTerm);
  }

  // ==================== جلب تصنيف واحد ====================
  
  @Get(':id')
  findOne(
    @Param('id', ParseUUIDPipe) id: string,
    @Param('storeId', ParseUUIDPipe) storeId: string,
    @Request() req,
  ) {
    return this.categoryService.findOne(id, storeId, req.user.userId);
  }

  // ==================== جلب منتجات التصنيف وأبنائه ====================
  
  @Get(':id/products')
  getProductsRecursive(
    @Param('id', ParseUUIDPipe) id: string,
    @Param('storeId', ParseUUIDPipe) storeId: string,
    @Query() queryDto: QueryProductsDto,
    @Request() req,
  ) {
    return this.categoryService.getCategoryProductsRecursive(
      id,
      storeId,
      req.user.userId,
      queryDto
    );
  }

  // ==================== إحصائيات التصنيف ====================
  
  @Get(':id/stats')
  getStats(
    @Param('id', ParseUUIDPipe) id: string,
    @Param('storeId', ParseUUIDPipe) storeId: string,
    @Request() req,
  ) {
    return this.categoryService.getStats(id, storeId, req.user.userId);
  }

  // ==================== تحديث تصنيف ====================
  
  @Patch(':id')
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Param('storeId', ParseUUIDPipe) storeId: string,
    @Body() dto: UpdateCategoryDto,
    @Request() req,
  ) {
    return this.categoryService.update(id, storeId, req.user.userId, dto);
  }

  // ==================== حذف تصنيف (Soft Delete) ====================
  
  @Delete(':id')
  @HttpCode(HttpStatus.OK)
  remove(
    @Param('id', ParseUUIDPipe) id: string,
    @Param('storeId', ParseUUIDPipe) storeId: string,
    @Request() req,
  ) {
    return this.categoryService.remove(id, storeId, req.user.userId);
  }

  // ==================== الحذف النهائي ====================
  
  @Delete(':id/force')
  @HttpCode(HttpStatus.OK)
  forceRemove(
    @Param('id', ParseUUIDPipe) id: string,
    @Param('storeId', ParseUUIDPipe) storeId: string,
    @Request() req,
  ) {
    return this.categoryService.forceRemove(id, storeId, req.user.userId);
  }

  // ==================== استعادة تصنيف محذوف ====================
  
  @Patch(':id/restore')
  restore(
    @Param('id', ParseUUIDPipe) id: string,
    @Param('storeId', ParseUUIDPipe) storeId: string,
    @Request() req,
  ) {
    return this.categoryService.restore(id, storeId, req.user.userId);
  }

  // ==================== نقل المنتجات بين التصنيفات ====================
  
  @Post(':id/move-products/:targetId')
  @HttpCode(HttpStatus.OK)
  moveProducts(
    @Param('id', ParseUUIDPipe) fromCategoryId: string,
    @Param('targetId', ParseUUIDPipe) toCategoryId: string,
    @Param('storeId', ParseUUIDPipe) storeId: string,
    @Request() req,
  ) {
    return this.categoryService.moveProducts(
      fromCategoryId,
      toCategoryId,
      storeId,
      req.user.userId
    );
  }
}